=================================================
-------------------------------------------------
<=== Beelzabub - A devil for the little guy! ===>
-------------------------------------------------
=================================================


Like the professional spread?

anyway:

Beelzabub is not much liked bymost of the worlds 
population is hated by most of the world. Not
many people appreciate his tireless work doom,
destruction... plagues and so on.

But now all of you retchidly hateful people can
do what you've all probably wanted to do for a 
while, have ago at blaming all the worlds 
problems on him, he probably caused them anyway!

And then the next stage may happen unabaided:

		HIS PUNISHMENT!!

A good punishment for most towards him is to frag
the red horny one of the face of q2dm3 utilising
the latest in depleted uranium slug technology.

You now know what you must do - kill the one from 
the deepest part of darkness and send him back to
his o so warm home.

--------------------------------------------------
==================================================
--------------------------------------------------

Beelzabub took 1 week to make and was made using
q2 model editor.
THe model was made from scratch and the skin was
made using the brilliant Npherno's skin tool.

Please unzip in the playes directory in a folder
deemed the name Beelzabub.

CTF skins for this littledevil are on the way...

Model, skins and all were made by Citrus Frog

The weapon .md2 was taken from the 'Borg' model
by Jude bond and the weapon skin is from the male 
model. Without htis there would be Null skin errors
blighting your game.

citrus.frog@becs-ltd.demon.co.uk

oh BTW Beelzabub has a home page at 

http:\\phrozen.quake2.co.uk

[there's nothing that odd about having a devil
 where hell phroze over.......................]
































For the curious who have read down here.. um..
..look both ways before crossing the street or something.


